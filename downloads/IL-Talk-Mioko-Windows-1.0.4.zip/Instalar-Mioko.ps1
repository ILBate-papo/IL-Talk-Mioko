﻿$ErrorActionPreference = 'Stop'
$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe", "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $edge) { throw 'Microsoft Edge nao encontrado. Instale o Edge e execute novamente.' }
$shell = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath('Desktop')
$menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'IL Talk Mioko'
New-Item -ItemType Directory -Force -Path $menu | Out-Null
foreach ($path in @((Join-Path $desktop 'IL Talk Mioko.lnk'), (Join-Path $menu 'IL Talk Mioko.lnk'))) {
    $link = $shell.CreateShortcut($path)
    $link.TargetPath = $edge
    $link.Arguments = '--app=https://mioko.il-talk.com.br/'
    $link.Description = 'IL Talk Mioko 1.0.4 - requer internet'
    $link.Save()
}
Start-Process -FilePath $edge -ArgumentList '--app=https://mioko.il-talk.com.br/'
Write-Host 'Mioko adicionada a area de trabalho e ao menu Iniciar.'
